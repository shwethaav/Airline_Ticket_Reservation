package com.airline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Airline_reservation_system {

	public static void main(String[] args) {
		SpringApplication.run(Airline_reservation_system.class, args);
		System.out.println("AirLine_Running");
	}

}
 